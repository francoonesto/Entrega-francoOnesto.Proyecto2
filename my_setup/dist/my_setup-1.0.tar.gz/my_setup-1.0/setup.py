from setuptools import setup

setup(
    name="my_setup",
    version="1.0",
    description="Paquete de ejemplo distribuido",
    author="Clase 14 - Coder",
    author_email="coder@coder.com",
    packages=["paquete1"]
)